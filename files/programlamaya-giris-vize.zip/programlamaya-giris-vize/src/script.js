
document.addEventListener("DOMContentLoaded", function () {
  // Gerekli HTML elemanlarını seç
  const metinSecenekleri = document.querySelectorAll(".metin-sec");
  const okumaAlani = document.getElementById("masalOkumaAlani");
  const masalBasligi = document.getElementById("masalBasligi");
  const masalMetni = document.getElementById("masalMetni");

  // Her özgün metin ve aktarma metni bağlantısı için
  metinSecenekleri.forEach(function (link) {
    link.addEventListener("click", function (event) {
      // Sayfanın bağlantı nedeniyle yukarı sıçramasını engelle
      event.preventDefault();

      // Tıklanan bağlantının başlığını ve metnini al
      const baslik = link.getAttribute("data-baslik");
      const metin = link.getAttribute("data-metin");

      // Okuma alanına yalnızca seçilen metni yerleştir
      masalBasligi.textContent = baslik;
      masalMetni.innerHTML = metin
  .split("\n")
  .filter(paragraf => paragraf.trim() !== "")
  .map(paragraf => `<p>${paragraf}</p>`)
  .join("");

      // Okuma alanını görünür yap
      okumaAlani.style.display = "block";

      // Okuma alanına doğru sayfayı kaydır
      okumaAlani.scrollIntoView({
        behavior: "smooth",
        block: "start"
      });
    });
  });
});
