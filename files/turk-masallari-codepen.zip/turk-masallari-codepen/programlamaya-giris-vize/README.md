# Programlamaya-Giris-Vize

A Pen created on CodePen.

Github link: https://github.com/sulenurnebioglu05/turk-masallari/tree/main

Original URL: [https://codepen.io/editor/sule-the-bold/pen/01a17f6c-cc18-7fa0-b3c8-f69cd74aeb44](https://codepen.io/editor/sule-the-bold/pen/01a17f6c-cc18-7fa0-b3c8-f69cd74aeb44).

